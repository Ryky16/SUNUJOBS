 <section id="content">

 	<div class="container">
 		<div class="row">
 			<div class="col-md-20">
 				<div class="about-logo">
 					<h1><u>SUNUJOBS</u></h1>
 					<p> Vous pouvez nous contacter directement en utilisant notre numéro de téléphone
 						ou notre l'adresse email.
 					</p>
 					<p>vous voulez en savoir plus sur SUNUJOBS? Poser vos questions sur notre formulaire ci-dessous!</p>
 					<p>Nous vous contacterons dès que possible.</p>
 					<p>Préférez-vous appeler? Consultez notre numéro de téléphone.</p>
 				</div>
 			</div>
 		</div>
 		<div class="row">
 			<div class="col-md-6">
 				<p></p>

 				<!-- Form itself -->
 				<form name="sentMessage" id="contactForm" novalidate>
 					<h3>Posez vos questions</h3>
 					<div class="control-group">
 						<div class="controls">
 							<input type="text" class="form-control" placeholder="Nom complet" id="name" required data-validation-required-message="Please enter your name" />
 							<p class="help-block"></p>
 						</div>
 					</div>
 					<div class="control-group">
 						<div class="controls">
 							<input type="email" class="form-control" placeholder="Email" id="email" required data-validation-required-message="Please enter your email" />
 						</div>
 					</div>

 					<div class="control-group">
 						<div class="controls">
 							<textarea rows="30px" cols="150px" class="form-control" placeholder="Message" id="message" required data-validation-required-message="Please enter your message" minlength="5" data-validation-minlength-message="Min 5 characters" maxlength="999" style="resize:none"></textarea>
 						</div>
 					</div>
 					<div id="success"> </div> <!-- For success/fail messages -->
 					<button type="submit" class="btn btn-primary pull-right">Envoyer</button><br />
 				</form>
 			</div>
 			<!--div class="col-md-6">
 				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
 				<div style=" overflow:hidden;height:500px;width:600px;">
 					<div id = "gmap_canvas" style ="height:500px;width:600px;"> </div> </style>
 						#gmap_canvas img {
 							max - width: none!important;
 							background: none!important
 						} </style>
				   <a class="google-map-code" href="http://www.trivoo.net"id="get-map-data">trivoo</a> </div> 
					 <script type = "text/javascript">
 						function init_map() {
 							var myOptions = {
 								zoom: 14,
 								center: new google.maps.LatLng(40.805478, -73.96522499999998),
 								mapTypeId: google.maps.MapTypeId.ROADMAP
 							};
 							map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
 							marker = new google.maps.Marker({
 								map: map,
 								position: new google.maps.LatLng(40.805478, -73.96522499999998)
 							});
 							infowindow = new google.maps.InfoWindow({
 								content: "<b></b><br/><br/>"
 							});
 							google.maps.event.addListener(marker, "click", function() {
 								infowindow.open(map, marker);
 							});
 							infowindow.open(map, marker);
 						}
 					google.maps.event.addDomListener(window, 'load', init_map);
 				</script>
 			</div-->


 			<div class="col-md-6">
 				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3858.4871587518037!2d-17.51797738513742!3d14.74156217755876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xec112dc7e01464f%3A0x9d132b03c1277f6e!2sHuawei%20Technologies%20S%C3%A9n%C3%A9gal!5e0!3m2!1sfr!2ssn!4v1648131238089!5m2!1sfr!2ssn" width="700px" height="700px" style="border:8px;" allowfullscreen="" loading=""></iframe>

 				<div style="overflow:hidden;height:500px;width:600px;">
 					<div id="gmap_canvas" style="height:500px;width:600px;"> </div>
 					</style>
 					#gmap_canvas img {
 					max - width: none!important;
 					background: none!important
 					} </style>
 					<a class="google-map-code" href="http://www.trivoo.net" id="get-map-data">trivoo</a>
 				</div>
 				<script type="text/javascript">
 					function init_map() {
 						var myOptions = {
 							zoom: 20,
 							center: new google.maps.LatLng(40.805478, -73.96522499999998),
 							mapTypeId: google.maps.MapTypeId.ROADMAP
 						};
 						map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
 						marker = new google.maps.Marker({
 							map: map,
 							position: new google.maps.LatLng(40.805478, -73.96522499999998)
 						});
 						infowindow = new google.maps.InfoWindow({
 							content: "<b></b><br/><br/>"
 						});
 						google.maps.event.addListener(marker, "click", function() {
 							infowindow.open(map, marker);
 						});
 						infowindow.open(map, marker);
 					}
 					google.maps.event.addDomListener(window, 'load', init_map);
 				</script>
 			</div>
 		</div>
 	</div>
 	</div>

 </section>
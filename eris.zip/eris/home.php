  <section id="banner">

    <!-- Slider -->
    <div id="main-slider" class="flexslider">
      <ul class="slides">
        <li>
          <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/scaled.webp" alt="" />
          <div class="flex-caption">
            <h3>Innovation</h3>
            <p>Nous créons les opportunités</p>

          </div>
        </li>
        <li>
          <img src="<?php echo web_root; ?>plugins/home-plugins/img/slides/woman_at_computer.jpg" alt="" />
          <div class="flex-caption">
            <h3>SPECIALISER</h3>
            <p>Le succès Dépend Du Travail</p>

          </div>
        </li>
      </ul>
    </div>
    <!-- end slider -->

  </section>
  <section id="call-to-action-2">
    <div class="container">
      <div class="row">
        <div class="col-md-10 col-sm-9">
          <h2>Explorez SUNUJOBS</h2>
          <p>Les personnes intéressées à trouver un emploi peuvent parcourir nos offres d’emploi ou rechercher des postes spécifiques à leurs compétences, puis créer un compte gratuit qui leur permet de soumettre leur nom.</p>
          <p>Avec un compte, le site offre un soutien supplémentaire, y compris la notification aux personnes lorsque des emplois qui correspondent à leurs critères sont publiés.
            Les chercheurs d’emploi peuvent rechercher des postes par emploi ou par échelle salariale au fur et à mesure qu’ils commencent leur recherche.</p>
        </div>
        <!--  <div class="col-md-2 col-sm-3">
          <a href="#" class="btn btn-primary">Read More</a>
        </div> -->
      </div>
    </div>
  </section>

  <section id="content">


    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aligncenter">
            <h2 class="aligncenter">COMPAGNIE</h2><!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus ovident, doloribus omnis minus temporibus perferendis nesciunt.. -->
          </div>
          <br />
        </div>
      </div>

      <?php
      $sql = "SELECT * FROM `tblcompany`";
      $mydb->setQuery($sql);
      $comp = $mydb->loadResultList();


      foreach ($comp as $company) {
        # code...

      ?>
        <div class="col-sm-4 info-blocks">
          <i class="icon-info-blocks fa fa-building-o"></i>
          <div class="info-blocks-in">
            <h3><?php echo $company->COMPANYNAME; ?></h3>
            <!-- <p><?php echo $company->COMPANYMISSION; ?></p> -->
            <p>Addresse :<?php echo $company->COMPANYADDRESS; ?></p>
            <p>Contacte :<?php echo $company->COMPANYCONTACTNO; ?></p>
          </div>
        </div>

      <?php } ?>
    </div>
  </section>

  <section class="section-padding gray-bg">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-title text-center">
            <h2>EMPLOIS POPULAIRES</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 ">
          <?php
          $sql = "SELECT * FROM `tblcategory`";
          $mydb->setQuery($sql);
          $cur = $mydb->loadResultList();

          foreach ($cur as $result) {
            echo '<div class="col-md-3" style="font-size:15px;padding:5px">* <a href="' . web_root . 'index.php?q=category&search=' . $result->CATEGORY . '">' . $result->CATEGORY . '</a></div>';
          }

          ?>
        </div>
      </div>

    </div>
  </section>
  <section id="content-3-10" class="content-block data-section nopad content-3-10">
    <div class="image-container col-sm-6 col-xs-12 pull-left">
      <div class="background-image-holder">

      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 col-sm-offset-6 col-xs-12 content">
          <div class="editContent">
            <h3>Notre équipe</h3>
          </div>
          <div class="editContent" style="height:235px;">
            <p>
              &nbsp;&nbsp; Notre style de travail collaboratif met l’accent sur le travail d’équipe, la confiance et la tolérance des opinions divergentes. Les gens nous disent que nous sommes terre-à-terre, accessibles et amusants.<br /><br />

              &nbsp;&nbsp;Nous avons une passion pour les vrais
              résultats de nos candidats et une volonté pragmatique d’action qui commence lundi matin à 8h et ne lâche rien. Nous disposons d’une équipe extraordinaire, capable de relever les grands défis du secteur.<br /><br />

              &nbsp;&nbsp;Nous ne faisons jamais cavalier seul.C'est pourquoi nous aidons les chercheurs d'emploi à obtenir des emplois stables et appropriés à leurs profils.
              &nbsp;&nbsp;Nous nous engageons pour le développement professionnel de nos collaborateurs dans un environnement de travail digne et sûr.</p>
          </div>
        </div>
      </div><!-- /.row-->
    </div><!-- /.container -->
  </section>

  <div class="about home-about">
    <div class="container">

      <div class="row">
        <div class="col-md-4">
          <!-- Heading and para -->
          <div class="block-heading-two">
            <h3><span>Foctionnalités</span></h3>
          </div>
          <p>Ceux sur SUNUJOBS ont accès à beaucoup de fonctionnalités, telles que:</p>
          <ul role="list">
            <p><li _msthash="2507576" _msttexthash="2920983">Création de profil</li></p>
            <p><li _msthash="2507577" _msttexthash="3752554">Recherche d'emploi</li></p>
            <p><li _msthash="2507578" _msttexthash="502684">Possibilité de faire des recherches avancée, par entreprises, par fonctions et par titres</li></p>
            <p><li _msthash="2507579" _msttexthash="9460646">Profil de l'entreprise</li></p>
            <p><li _msthash="2507580" _msttexthash="303121">Information sur l'offre d'emplois</li></p>
            <p><li _msthash="2507581" _msttexthash="348699">Informations personnelles</li></p>
            <p><li _msthash="2507582" _msttexthash="3586921">Générateur de CV</li></p>

          </ul>
          <!--p>Notre programme est de traquer minutieusement les postes vacants disponibles;
            en permettant aux chômeurs de postuler gratuitement en ligne;<br><br>Ainsi qu'en fournissant d'autres services utiles pour aider les sans emplois. <br><br>Nous travaillons aussi quotidiennement pour mettre à la disposition des candidats à l'emploi du Sénégal, de la Diaspora et de la sous-région francophone, des opportunités et des services pour faciliter leur recherche.</p-->
        </div>
        <div class="col-md-4">
          <div class="block-heading-two">
            <h3><span>Dernières nouvelles</span></h3>
          </div>
          <!-- Accordion starts -->
          <div class="panel-group" id="accordion-alt3">
            <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
            <div class="panel">
              <!-- Panel heading -->
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
                    <i class="fa fa-angle-right"></i>
                    Formation professionnelle
                    Inscription à la Formation Professionnelle Ecole-Entreprise PF2E
                  </a>
                </h4>
              </div>
              <div id="collapseOne-alt3" class="panel-collapse collapse">
                <!-- Panel body -->
                <div class="panel-body">
                  Ce projet de formation professionnelle s’adresse aux jeunes (hommes et femmes) qui ont au minimum 16 ans et qui sont à la recherche d’une qualification professionnelle. Il s’agit d’un projet lancé par le Ministère de la Formation, de l’Apprentissage et de l’Artisanat et, devant aider à l’employabilité d’au moins 10.000 jeunes au Sénégal.
                  <br /><br />
                </div>
              </div>
            </div>
            <div class="panel">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseTwo-alt3">
                    <i class="fa fa-angle-right"></i>SAMABON 3FPT : Financement à 90% de votre formation professionnelle
                  </a>
                </h4>
              </div>
              <div id="collapseTwo-alt3" class="panel-collapse collapse">
                <div class="panel-body">
                  Les personnes désirant faire une formation professionnelle et technique pourront bénéficier d’un bon pour une formation financée à hauteur de 90%. Cela s’adresse essentiellement aux jeunes qui n’ont pas de qualification professionnelle et qui sont activement à la recherche d’une formation qualifiante,
                  ainsi qu’aux jeunes porteurs d’un projet orienté vers l’emploi ou l’auto-emploi qui sont à la recherche d’un financement. Le financement est accessible dès l’âge de 16 ans.
                </div>
              </div>
            </div>
            <div class="panel">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseThree-alt3">
                    <i class="fa fa-angle-right"></i> Recrutement Fonction Publique Sénégal
                  </a>
                </h4>
              </div>
              <div id="collapseThree-alt3" class="panel-collapse collapse">
                <div class="panel-body">
                  Dans le cadre du programme pluriannuel de recrutement dans la Fonction publique, le Gouvernement du Sénégal a ouvert 5415 postes à vocation technique et interministérielle.

                  Pour la mise en oeuvre de ce programme, les candidats à un emploi sont invités à s’inscrire, à la plateforme électronique suivante <a href="https://emploi-fpublique.sec.gouv.sn/" target="_blank" rel="noopener" data-slimstat="5">emploi-fpublique.sec.gouv.sn</a>
                </div>
              </div>
            </div>
            <div class="panel">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseFour-alt3">
                    <i class="fa fa-angle-right"></i> portails étudiants au Sénégal
                  </a>
                </h4>
              </div>
              <div id="collapseFour-alt3" class="panel-collapse collapse">
                <div class="panel-body">
                  Si vous êtes nouveau bachelier ou un potentiel étudiant au Sénégal , plus besoin de sacrifier à des procédures administratives souvent longues et fastidieuses,<a href="https://campusen.sn/" target="_blank" rel="noopener" data-slimstat="5">Campusen</a> (Campus Sénégal) vous facilite les choses.
                </div>
              </div>
            </div>
          </div>
          <!-- Accordion ends -->

        </div>

        <div class="col-md-4">
          <div class="block-heading-two">
            <h3><span>Témoignages</span></h3>
          </div>
          <div class="testimonials">
            <div class="active item">
              <blockquote>
                <p>Depuis notre création, nous connaissons
                  une expansion de notre activité grâce à la qualité des candidats découverts via SUNUJOBS.
                  La diffusion de nos offres sur ce site nous a permis de recruter de bon candidats.Nous sommes très satisfaits de l'utilisation de SUNUJOBS.
                </p>
              </blockquote>
              <div class="carousel-info">
                <img alt="" src="plugins/home-plugins/img/avatar.png" class="pull-left">
                <div class="pull-left">
                  <span class="testimonials-name">Marc Jerry</span>
                  <span class="testimonials-post">Directeur Technique</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>



      <br>

    </div>

  </div>
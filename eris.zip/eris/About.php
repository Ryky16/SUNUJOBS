 <section id="content">
 	<section class="section-padding">
 		<div class="container">
 			<div class="row showcase-section">
 				<div class="col-md-9">
 					<img src="plugins/home-plugins/img/teleconseiller.jpg" alt="showcase img">
 				</div>


 				<div class="col-md-3">
 					<div class="about-text">
 						<h3><u>Notre Mission</u></h3>
 						<p>Garantir à nos clients, le recrutement et la mise à disposition des meilleurs</p>
 						<p>profils du marché correspondant à leurs attentes, en utilisant des méthodes</p>
 						<p>de sélections efficaces et personnalisées.</p>
 						<h4>« Pour nous, chaque client est unique et chaque besoin est spécifique »</h4>
 						<p>Nous avons pour objectif de vous proposer une solution sur
 							mesure afin de répondre à vos attentes avec rigueur et professionnalisme.</p><br />
 						<p>Notre groupe de consultants forts de leur expérience dans le secteur secondaire porte une attention particulière sur la qualité des canditats recrutés.</p>
 						<p>Le professionnalisme qui est de rigueur vise le développement de relations durables et honnêtes avec nos clients.</p>
 						<p></p>
 					</div>
 				</div>
 			</div>
 		</div>
 	</section>

 	<div class="container">

 		<div class="about">

 			<div class="row">
 				<div class="col-md-4">
 					<!-- Heading and para -->
 					<div class="block-heading-two">
 						<h3><span>Pourquoi nous choisir?</span></h3>
 					</div>

 					<p>Il y'a plein de bonne raison de travailer avec nous.</p>
 					<p>SUNUJOBS s'engage à mettre à votre disposition du
 						personnel expérimenté pour des missions sur l'ensemble du
 						territoire national et dans la sous région.
 					</p>
 					<p>Nous apporterons des réponses concrètes et efficace à la demande
 						permanente dans le milieux technologies, industriels et manufacturs</p>
 					<p>Déterminés à offrir des services de première qualité, SUNUJOBS se fixe
 						pour unique mission : la satisfaction de ses collaborateurs!!!
 					</p>

 				</div>
 				<div class="col-md-4">
 					<div class="block-heading-two">
 						<h3><span>Notre solution</span></h3>
 					</div>

 					<!-- Accordion starts -->
 					<div class="panel-group" id="accordion-alt3">
 						<!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
 						<div class="panel">
 							<!-- Panel heading -->
 							<div class="panel-heading">
 								<h4 class="panel-title">
 									<a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
 										<i class="fa fa-angle-right"></i>Les Chercheurs D'emplois
 									</a>
 								</h4>
 							</div>

 							<div id="collapseOne-alt3" class="panel-collapse collapse">

 								<!-- Panel body -->

 								<div class="panel-body">
 									Nous vous aidons à trouver des emplois ou de brillants candidats, votre confiance nous est précieuse.
 									Et pour l'honorer, nous investissons massivement dans la protection de vos données personnelles.
 									Nous vous mettrons sur un pied d'égalité en vous fournissant un vaste ensemble de droits.
 								</div>
 							</div>
 						</div>
 						<div class="panel">
 							<div class="panel-heading">
 								<h4 class="panel-title">
 									<a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseTwo-alt3">
 										<i class="fa fa-angle-right"></i> Rendre nos offres plus attractives
 									</a>
 								</h4>
 							</div>
 							<div id="collapseTwo-alt3" class="panel-collapse collapse">
 								<div class="panel-body">
 									Toujours à l'écoute de vos besoins,SUNUJOBS fait continuellement évoluer ses services en ligne.
 									c'est particulièrement le cas de la publication d'offres d'emploi, une fonctionnalité qui fait l'objet d'un soin particulier.

 								</div>
 							</div>
 						</div>
 						<div class="panel">
 							<div class="panel-heading">
 								<h4 class="panel-title">
 									<a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseThree-alt3">
 										<i class="fa fa-angle-right"></i>Réduire Le Chômage
 									</a>
 								</h4>
 							</div>
 							<div id="collapseThree-alt3" class="panel-collapse collapse">
 								<div class="panel-body">
 									Le but ici est, d’une part, est de rendre le chômage plus tolérable et réduire ainsi les risques de pression sociale ;
 									d’autre part, limiter les effets de ce cercle vicieux (crise, licenciement,baisse de revenus distribués, baisse de la demande et l'accentuation de la crise)
 									en accordant ces revenus de substitution.
 									Cette politique encourage aussi la réduction de l’offre de travail, notamment en développant les préretraites,
 									encourageant les immigrés de retourner dans leurs pays d’origine.
 								</div>
 							</div>
 						</div>
 						<div class="panel">
 							<div class="panel-heading">
 								<h4 class="panel-title">
 									<a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseFour-alt3">
 										<i class="fa fa-angle-right"></i> Nos communautés d’actifs
 									</a>
 								</h4>
 							</div>
 							<div id="collapseFour-alt3" class="panel-collapse collapse">
 								<div class="panel-body">
 									Pour bien s'adresser à un actif, il faut savoir lui parler. Et pour lui parler : il faut savoir ce qu'il aime et ce qu'il recherche. C'est ce que nous faisons chaque jour
 									en échangeant avec les menbres de notre communautés.
 								</div>
 							</div>
 						</div>
 					</div>
 					<!-- Accordion ends -->

 				</div>

 				<div class="col-md-4">
 					<div class="block-heading-two">
 						<h3><span>Notre Expertise</span></h3>
 					</div>
 					<p>Le savoir-faire de nos collaborateurs nous ont valu beaucoup de succès dans le placement de personnel et le recrutement,
 						notamment dans des secteurs de l’immobilier, de l’agroalimentaire, de la pêche, des bâtiments et travaux publics etc.
 					</p>
 					<p>Trouver « L’Homme qu’il faut à la place qu’il faut » pour intégrer de façon harmonieuse et efficace à votre équipe de travail avec toutes les garanties qui sied est souvent un processus long, ardu et complexe. </p>
 				</div>

 			</div>



 			<br>
 			<!-- Our Team starts -->

 			<!-- Heading -->
 			<!--div class="block-heading-six">
 				<h4 class="bg-color">Notre Equipe</h4>
 			</div>
 			<br-->

 			<!-- Our team starts -->

 			<div class="team-six">
 				<div class="row">
 					<div class="col-md-3 col-sm-6">
 						<!-- Team Member -->
 						<div class="team-member">
 							<!-- Image -->
 							<img class="img-responsive" src="img/team1.jpg" alt="">
 							<!-- Name -->
 							<h4>Henri</h4>
 							<span class="deg">Créateur</span>
 						</div>
 					</div>
 					<div class="col-md-3 col-sm-6">
 						<!-- Team Member -->
 						<div class="team-member">
 							<!-- Image -->
 							<img class="img-responsive" src="img/team2.jpg" alt="">
 							<!-- Name -->
 							<h4>Mansour</h4>
 							<span class="deg">Développeur</span>
 						</div>
 					</div>
 					<div class="col-md-3 col-sm-6">
 						<!-- Team Member -->
 						<div class="team-member">
 							<!-- Image -->
 							<img class="img-responsive" src="img/team3.jpg" alt="">
 							<!-- Name -->
 							<h4>Rose</h4>
 							<span class="deg">Gérante</span>
 						</div>
 					</div>
 					<div class="col-md-3 col-sm-6">
 						<!-- Team Member -->
 						<div class="team-member">
 							<!-- Image -->
 							<img class="img-responsive" src="img/team4.jpg" alt="">
 							<!-- Name -->
 							<h4>Harris</h4>
 							<span class="deg">Conseiller</span>
 						</div>
 					</div>
 				</div>
 			</div>

 			<!-- Our team ends -->


 		</div>

 	</div>
 </section>
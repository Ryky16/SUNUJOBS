
<?php 
require_once("include/initialize.php"); 
$content='home.php';
$view = (isset($_GET['q']) && $_GET['q'] != '') ? $_GET['q'] : '';
switch ($view) { 
	case 'apply' :
        $title="Soumettre une demande";	
		$content='applicationform.php';		
		break;
	case 'login' : 
        $title="Login";	
		$content='login.php';		
		break;
	case 'company':
        $title="COMPAGNIE";	
		$content='company.php';		
		break;
	case 'hiring' :
		$title = isset($_GET['search']) ? 'Embauche '.$_GET['search'] :"Embauche"; 
		$content='hirring.php';		
		break;		
	case 'category' :
        $title='Chercher'. $_GET['search'];	
		$content='category.php';		
		break;
	case 'viewjob' :
        $title= "Détails du poste";	
		$content='viewjob.php';		
		break;
	case 'success' :
        $title= "réussite";	
		$content='success.php';		
		break;
	case 'register' :
        $title= "Inscrire un nouveau membre";	
		$content='register.php';		
		break;
	case 'Contact' :
        $title='Contacter Nous';	
		$content='Contact.php';		
		break;	
	case 'About' :
        $title='Qui Somme-Nous';	
		$content='About.php';		
		break;	
	case 'advancesearch' :
        $title='Recherche Avancée';	
		$content='advancesearch.php';		
		break;	

	case 'result' :
        $title= 'Recherche avancée';	
		$content='advancesearchresult.php';		
		break;
	case 'search-company' :
        $title='Recherche Par Entreprise';	
		$content='searchbycompany.php';		
		break;	
	case 'search-function' :
        $title='Recherche Par Fonction';	
		$content='searchbyfunction.php';		
		break;	
	case 'search-jobtitle' :
        $title='Recherche Par Titre D’emploi';	
		$content='searchbytitle.php';		
		break;						
	default :
	    $active_home='active';
	    $title="Home";	
		$content ='home.php';		
}
require_once("theme/templates.php");
?>
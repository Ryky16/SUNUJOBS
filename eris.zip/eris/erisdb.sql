-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2021 at 05:07 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erisdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblapplicants`
--

CREATE TABLE `tblapplicants` (
  `APPLICANTID` int(11) NOT NULL,
  `FNAME` varchar(90) NOT NULL,
  `LNAME` varchar(90) NOT NULL,
  `MNAME` varchar(90) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `SEX` varchar(11) NOT NULL,
  `CIVILSTATUS` varchar(30) NOT NULL,
  `BIRTHDATE` date NOT NULL,
  `BIRTHPLACE` varchar(255) NOT NULL,
  `AGE` int(2) NOT NULL,
  `USERNAME` varchar(90) NOT NULL,
  `PASS` varchar(90) NOT NULL,
  `EMAILADDRESS` varchar(90) NOT NULL,
  `CONTACTNO` varchar(90) NOT NULL,
  `DEGREE` text NOT NULL,
  `APPLICANTPHOTO` varchar(255) NOT NULL,
  `NATIONALID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapplicants`
--

INSERT INTO `tblapplicants` (`APPLICANTID`, `FNAME`, `LNAME`, `MNAME`, `ADDRESS`, `SEX`, `CIVILSTATUS`, `BIRTHDATE`, `BIRTHPLACE`, `AGE`, `USERNAME`, `PASS`, `EMAILADDRESS`, `CONTACTNO`, `DEGREE`, `APPLICANTPHOTO`, `NATIONALID`) VALUES
(2018013, 'Khady', 'Diop', 'Dykha', 'Pikine', 'Female', 'none', '1991-01-01', 'Pikine', 27, 'Diop', 'a6312121e15caec74845b7ba5af23330d52d4ac0', 'diopkhady@gmail.com', '778564510', 'BAC', 'photos/RobloxScreenShot20180406_203758793.png', 'Senegalaise'),
(2018014, 'Bruno', 'Santos', 'nono', 'Yoff', 'Male', 'Maried', '1993-04-14', 'Thies', 25, 'nono', 'c8d99c2f7cd5f432c163abcd422672b9f77550bb', 'N.bruno@gmail.com', '14655623123123', 'Ingenieur', '', 'Senegalais'),
(2018015, 'HENRI-PIERRE', 'NUNEZ', 'simon', 'Dieupeule 4', 'Male', 'Single', '1989-01-27', 'Dakar', 26, 'Ryky', '1dd4efc811372cd1efe855981a8863d10ddde1ca', 'henripierre.nunez@uvs.edu.sn', '775246398', 'Sacré-coeur', 'photos/Skanks-logo.jpeg', ''),
(2022017, 'Marie', 'sarr', 'Jeanne', 'Rufisque', 'Female', 'Married', '1986-02-17', 'Dakar', 36, 'Jeanne', '319f10789879115f7c0913a3974513c3b4361582', 'M.jeanne@gmail.com', '772513649', 'Licence', '', 'Senegalaise');

-- --------------------------------------------------------

--
-- Table structure for table `tblattachmentfile`
--

CREATE TABLE `tblattachmentfile` (
  `ID` int(11) NOT NULL,
  `FILEID` varchar(30) DEFAULT NULL,
  `JOBID` int(11) NOT NULL,
  `FILE_NAME` varchar(90) NOT NULL,
  `FILE_LOCATION` varchar(255) NOT NULL,
  `USERATTACHMENTID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblattachmentfile`
--

INSERT INTO `tblattachmentfile` (`ID`, `FILEID`, `JOBID`, `FILE_NAME`, `FILE_LOCATION`, `USERATTACHMENTID`) VALUES
(2, '2147483647', 2, 'Resume', 'photos/27052018124027PLATENO FE95483.docx', 2018013);

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--

CREATE TABLE `tblautonumbers` (
  `AUTOID` int(11) NOT NULL,
  `AUTOSTART` varchar(30) NOT NULL,
  `AUTOEND` int(11) NOT NULL,
  `AUTOINC` int(11) NOT NULL,
  `AUTOKEY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumbers`
--

INSERT INTO `tblautonumbers` (`AUTOID`, `AUTOSTART`, `AUTOEND`, `AUTOINC`, `AUTOKEY`) VALUES
(1, '02983', 7, 1, 'userid'),
(2, '000', 78, 1, 'employeeid'),
(3, '0', 16, 1, 'APPLICANT'),
(4, '69125', 29, 1, 'FILEID');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CATEGORYID` int(11) NOT NULL,
  `CATEGORY` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CATEGORYID`, `CATEGORY`) VALUES
(10, 'Santé'),
(11, 'TI'),
(12, 'Marketing/Communication'),
(13, 'Finance'),
(14, 'RH'),
(15, 'Achats'),
(23, 'Comptabilité'),
(24, 'Arts et design'),
(25, 'Entrepreneuriat'),
(26, 'Immobilier'),
(27, 'DISTRIBUTEURS'),
(28, 'Chauffeur');

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `COMPANYID` int(11) NOT NULL,
  `COMPANYNAME` varchar(90) NOT NULL,
  `COMPANYADDRESS` varchar(90) NOT NULL,
  `COMPANYCONTACTNO` varchar(30) NOT NULL,
  `COMPANYSTATUS` varchar(90) NOT NULL,
  `COMPANYMISSION` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`COMPANYID`, `COMPANYNAME`, `COMPANYADDRESS`, `COMPANYCONTACTNO`, `COMPANYSTATUS`, `COMPANYMISSION`) VALUES
(2, 'TIENS DSCOM', 'Dakar/Sénégal', '783790383', '', ''),
(4, 'YANGO', 'Dakar/Sénégal', 'yango.yandex.com/company', '', ''),
(6, 'GBG', 'Dakar/Sénégal', '33 869 59 00', '', ''),
(7, 'Seneca', 'vp.greenseeds@gmail.com', '', '', ''),
(8, 'TERSEA', 'Dakar/Sénégal', 'rh.senegal@tersea.com', '', ''),
(9, 'Groupe Baobab', '1 rue de Gramont 75002,Paris,France', 'Contact@baobabgroup.com', '', ''),
(10, 'Wave', 'Dakar/Sénégal', 'www.wave.com', '', ''),
(11, 'Phoenix Consulting', 'Dakar,Sénégal', 'recrutementpcgsn@gmail.com', '', ''),
(13, 'RAES ONG', 'Dakar/Sénégal', '338426515', '', ''),
(14, 'Webhelp Sénégal', 'Sénégal', 'https://jobs.webhelp.com/caree', '', ''),
(15, 'Ermit MPASSI', 'Dakar/VDN', '762185898', '', ''),
(16, 'SANTARGILE', 'Dakar/Almadies', '762242546', '', '');


-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `INCID` int(11) NOT NULL,
  `EMPLOYEEID` varchar(30) NOT NULL,
  `FNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL,
  `MNAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(90) NOT NULL,
  `BIRTHDATE` date NOT NULL,
  `BIRTHPLACE` varchar(90) NOT NULL,
  `AGE` int(11) NOT NULL,
  `SEX` varchar(30) NOT NULL,
  `CIVILSTATUS` varchar(30) NOT NULL,
  `TELNO` varchar(40) NOT NULL,
  `EMP_EMAILADDRESS` varchar(90) NOT NULL,
  `CELLNO` varchar(30) NOT NULL,
  `POSITION` varchar(50) NOT NULL,
  `WORKSTATS` varchar(90) NOT NULL,
  `EMPPHOTO` varchar(255) NOT NULL,
  `EMPUSERNAME` varchar(90) NOT NULL,
  `EMPPASSWORD` varchar(125) NOT NULL,
  `DATEHIRED` date NOT NULL,
  `COMPANYID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`INCID`, `EMPLOYEEID`, `FNAME`, `LNAME`, `MNAME`, `ADDRESS`, `BIRTHDATE`, `BIRTHPLACE`, `AGE`, `SEX`, `CIVILSTATUS`, `TELNO`, `EMP_EMAILADDRESS`, `CELLNO`, `POSITION`, `WORKSTATS`, `EMPPHOTO`, `EMPUSERNAME`, `EMPPASSWORD`, `DATEHIRED`, `COMPANYID`) VALUES
(76, '2018001', 'Yves', 'Ndoye', 'Ahmad', 'Mermoz', '1994-09-04', 'Dakar', 27, 'Male', 'Single', '771249716', 'Yvesndoye16@gmail.com', '', 'Informatique', '', '', '2018001', 'f3593fd40c55c33d1788309d4137e82f5eab0dea', '2021-04-02', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tblfeedback`
--

CREATE TABLE `tblfeedback` (
  `FEEDBACKID` int(11) NOT NULL,
  `APPLICANTID` int(11) NOT NULL,
  `REGISTRATIONID` int(11) NOT NULL,
  `FEEDBACK` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbljob`
--

CREATE TABLE `tbljob` (
  `JOBID` int(11) NOT NULL,
  `COMPANYID` int(11) NOT NULL,
  `CATEGORY` varchar(250) NOT NULL,
  `OCCUPATIONTITLE` varchar(90) NOT NULL,
  `REQ_NO_EMPLOYEES` int(11) NOT NULL,
  `SALARIES` double NOT NULL,
  `DURATION_EMPLOYEMENT` varchar(90) NOT NULL,
  `QUALIFICATION_WORKEXPERIENCE` text NOT NULL,
  `JOBDESCRIPTION` text NOT NULL,
  `PREFEREDSEX` varchar(30) NOT NULL,
  `SECTOR_VACANCY` text NOT NULL,
  `JOBSTATUS` varchar(90) NOT NULL,
  `DATEPOSTED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbljob`
--

INSERT INTO `tbljob` (`JOBID`, `COMPANYID`, `CATEGORY`, `OCCUPATIONTITLE`, `REQ_NO_EMPLOYEES`, `SALARIES`, `DURATION_EMPLOYEMENT`, `QUALIFICATION_WORKEXPERIENCE`, `JOBDESCRIPTION`, `PREFEREDSEX`, `SECTOR_VACANCY`, `JOBSTATUS`, `DATEPOSTED`) VALUES
(3, 6, 'Comptabilité', 'Comptabilité (bac+4) ', 0, 300000, 'CDD', 'Gestion comptable', 'Maitriser les logiciels informatiques', 'Homme/Femme', '', '', '2022-03-09 01:10:00'),
(4, 9,  'TI', 'Informatique(bac+5)', 1, 500000, '3 mois', '-Expérience pratique des envinnements Windows/Linux/Mac OS. Capcité à diagnostiquer et à résoudre des problèmes techniques de base.', 'Surveillance des applications. Poser des questions ciblées aux clients pour comprendre rapidement lorigine du problème.', 'Homme/Femme', '', '', '2022-03-09 01:30:00'),
(5, '7', 'Comptabilité', 'Comptabilité(BAC+2)', '0', '0', '4 mois', 'BAC+2 en comptabilité, gestion avec au moins 2 ans d’expérience en tant que comptable.', 'Excellente maîtrise d’Excel et Word .Maîtriser obligatoirement Sage gestion commercial-comptabilité et paie.Être rigoureux précis, à l’écoute.Capacité à suivre l’évolution de la société', 'Homme/Femme', '', '', '2022-03-09 14:47:00'),
(6, '11', ' Immobilier', 'commerce Immobilier (bac+3) ', '0', '0', '', 'Etre titulaire dun diplôme universitaire+3 en commerce.Avoir au moins une années dexpérience professionnelle serait un atout. Bonne maitrise du Pack Office.', 'Faire preuve de rigueur et dorganisation. Faire preuve de réactivité. Etre autonome et méticieux. ', 'Homme/Femme', '', '', '2022-03-09 14:59:00'),
(7, '4', 'Chauffeur', 'Chauffeur (2 ans)', '0', '0', 'CDI', 'Expérience de conduite en catégorie B .Style de conduite prudentrnConnaissance de la ville ou capacité à utiliser un navigateur.', 'Transport des clients en voiture personnelle.Travailler avec une application installée sur votre smartphone – Yandex.Réalisation des commandes selon les normes de Yandex. Garder la voiture propre et rangée.', 'Homme/Femme', '', '', '2022-03-09 16:35:00'),
(8, '8', 'Marketing/Communication', 'Marketing (Bac+2)', '0', '0', 'CDI', 'une bonne élocution et une écoute active, le goût pour le téléphone et l’outil informatiqueMaîtriser les techniques de vente par téléphone,Bien connaître les aspects techniques des produits pour répondre avec précision aux demandes de la clientèleSavoir travailler en équipe,Etre tenace réactif et force de proposition.', 'Faire de la prospection, contacter des clients potentiels et à travers votre courtoisie et votre convivialité identifier leurs besoinsDévelopper un argumentaire de vente qui correspond à ces besoins afin de conclure des contratsFidéliser les client en veillant à ce qu’ils aient tous les conseils et les informations qu’ils désirent et en s’assurant de leur satisfaction,Assurer le suivi informatique des commandes.', 'Homme/Femme', '', '', '2022-03-09 17:07:00'),
(9, '10', 'DISTRIBUTEURS', 'Bonnes capacités relationnelles et commerciales.', '0', '0', 'CDD de 2 mois avec 1 mois de période d’essai', '6+ mois d’expérience de travail dans les ventes sur le terrain, en particulier dans les équipes de distributionAvoir un smartphone.Bonne maîtrise de la technologie – ce métier nécessite une bonne maîtrise des smartphones.Sont courtois, matures, proactifs et cohérents.', 'Faites la promotion de l’application et des services Wave auprès de clients potentiels.Promouvoir quotidiennement Wave dans les zones désignées en suivant les instructions des superviseurs.rnUtilisez de manière efficace vos supports au quotidien pour créer de nouveaux utilisateurs.rnEncouragez et motivez les clients à utiliser leur application en veillant à ce qu’ils reçoivent une assistance adéquate.rnRendre compte quotidiennement de la distribution, des besoins et des retours du terrain à la hiérarchie.rnAidez à faire connaître Wave Mobile Money, y compris ses avantages pour les clients.', 'Homme/Femme', '', '', '2022-03-09 17:30:00'),
(10, '2', 'Entrepreneuriat', 'Divers profil', '0', '0', '', 'Etudiant,élève,diplômé,Chômeur,retraité femme aun foyer, délégué médicale', 'Nous somme à la recherche des personnes dynamiques et responsables.Des séances dinformations, des séminaires de présentation sont organisées pour toutes personnes désirantes de connaître nos avantages.', 'Homme/Femme', '', '', '2022-03-09 18:19:00'),
(10, '13', 'Arts et design', 'Production numérique (bac+3)', '0', '400000', 'CDD', 'Réaliser des supports graphiques pour le print, le digital et le web. Créer des identités visuelles complètes, de templates,gabarits et divers outils.', 'Réalise des supports graphiques dédition(documents type, papeteries, cartes de visites,gabarits doc/powerpoint. pour le compte du RAES et des projets. Réalise une charte graphique complète et conçoit des supports en fonction des besoins des projets.Assurer de la conformité des documents. Créer les visuels pour les différents canaux de RAES.', 'Homme/Femme', '', '', '2022-03-09 20:03:00'),
(11, '14', 'RH', ' Ressources Humaines(bac+5)', '0', '0', 'CDI', 'Titulaire d’un Bac +4/5 en Ressources Humaines.Sens de l’organisation et du respect des délais.Autonomie, dynamisme, excellentes qualités relationnelles.', 'Accompagner les équipes opérationnelles pour mettre en place des solutions.Amélioration des méthodes RH au niveau transverse.Prise en charge des projets RH pour lensemble de la filiale.Construire un climat social de qualité à mettre en place la politique de ressources humaines de lentreprise.', 'Homme/Femme', '', '', '2022-03-10 00:06:00'),
(12, '15', 'Service de la santé', 'Expérience (1an)', '0', '0', 'Temps partiel', 'Avoir une expérience plus de 1an sur ce poste.', 'Nous cherchons des partenaires dans le domaine médical. Veillez nous contacter.', 'Homme/Femme', '', '', '2022-03-10 00:35:00');
-- --------------------------------------------------------

--
-- Table structure for table `tbljobregistration`
--

CREATE TABLE `tbljobregistration` (
  `REGISTRATIONID` int(11) NOT NULL,
  `COMPANYID` int(11) NOT NULL,
  `JOBID` int(11) NOT NULL,
  `APPLICANTID` int(11) NOT NULL,
  `APPLICANT` varchar(90) NOT NULL,
  `REGISTRATIONDATE` date NOT NULL,
  `REMARKS` varchar(255) NOT NULL DEFAULT 'Pending',
  `FILEID` varchar(30) DEFAULT NULL,
  `PENDINGAPPLICATION` tinyint(1) NOT NULL DEFAULT 1,
  `HVIEW` tinyint(1) NOT NULL DEFAULT 1,
  `DATETIMEAPPROVED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbljobregistration`
--

INSERT INTO `tbljobregistration` (`REGISTRATIONID`, `COMPANYID`, `JOBID`, `APPLICANTID`, `APPLICANT`, `REGISTRATIONDATE`, `REMARKS`, `FILEID`, `PENDINGAPPLICATION`, `HVIEW`, `DATETIMEAPPROVED`) VALUES
(1, 9, 4, '2022016', 'HENRI-PIERRE NUNEZ', '2022-03-09', 'Pending', '20226912530', '0', '1', '2022-03-09 00:37:22'),
(2, 16, 15, '2022017', 'Marie sarr', '2022-03-24', 'Pending', '20226912531', '1', '1', '2022-03-24 16:42:00');
-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `USERID` varchar(30) NOT NULL,
  `FULLNAME` varchar(40) NOT NULL,
  `USERNAME` varchar(90) NOT NULL,
  `PASS` varchar(90) NOT NULL,
  `ROLE` varchar(30) NOT NULL,
  `PICLOCATION` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`USERID`, `FULLNAME`, `USERNAME`, `PASS`, `ROLE`, `PICLOCATION`) VALUES
('00018', 'jobs', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator', 'photos/Koala.jpg'),
('2018001', 'Yves Ndoye', 'Ndoye', 'f3593fd40c55c33d1788309d4137e82f5eab0dea', 'Employee', ''),
('N00452020', 'Amina Seck', 'Seck', '43f0fe475f4a494f242fee416dee053d21670bd4', 'Employee', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblapplicants`
--
ALTER TABLE `tblapplicants`
  ADD PRIMARY KEY (`APPLICANTID`);

--
-- Indexes for table `tblattachmentfile`
--
ALTER TABLE `tblattachmentfile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  ADD PRIMARY KEY (`AUTOID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CATEGORYID`);

--
-- Indexes for table `tblcompany`
--
ALTER TABLE `tblcompany`
  ADD PRIMARY KEY (`COMPANYID`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`INCID`),
  ADD UNIQUE KEY `EMPLOYEEID` (`EMPLOYEEID`);

--
-- Indexes for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  ADD PRIMARY KEY (`FEEDBACKID`);

--
-- Indexes for table `tbljob`
--
ALTER TABLE `tbljob`
  ADD PRIMARY KEY (`JOBID`);

--
-- Indexes for table `tbljobregistration`
--
ALTER TABLE `tbljobregistration`
  ADD PRIMARY KEY (`REGISTRATIONID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`USERID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblapplicants`
--
ALTER TABLE `tblapplicants`
  MODIFY `APPLICANTID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2018016;

--
-- AUTO_INCREMENT for table `tblattachmentfile`
--
ALTER TABLE `tblattachmentfile`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  MODIFY `AUTOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CATEGORYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tblcompany`
--
ALTER TABLE `tblcompany`
  MODIFY `COMPANYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `INCID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  MODIFY `FEEDBACKID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbljob`
--
ALTER TABLE `tbljob`
  MODIFY `JOBID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbljobregistration`
--
ALTER TABLE `tbljobregistration`
  MODIFY `REGISTRATIONID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;





//hdKwWJ8dSBea5&8@44&d